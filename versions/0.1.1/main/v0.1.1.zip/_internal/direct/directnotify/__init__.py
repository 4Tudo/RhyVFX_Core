"""
This package contains notification and logging utilities for Python code.
"""
