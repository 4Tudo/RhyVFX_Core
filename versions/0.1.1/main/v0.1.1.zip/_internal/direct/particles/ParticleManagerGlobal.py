"""
Contains the global particle system manager
"""
from panda3d.physics import ParticleSystemManager

particleMgr = ParticleSystemManager()
