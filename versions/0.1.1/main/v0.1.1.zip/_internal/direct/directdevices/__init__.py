"""
This package contains a high-level interface for VRPN devices.

Also see the :mod:`panda3d.vprn` module.
"""
