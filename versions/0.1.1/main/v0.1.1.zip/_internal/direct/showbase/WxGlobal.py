""" This module is now vestigial.  """


def spawnWxLoop():
    """Alias for :meth:`base.spawnWxLoop() <.ShowBase.spawnWxLoop>`."""
    base.spawnWxLoop()
