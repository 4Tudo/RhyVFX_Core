from ursina import *
from ursina.shaders.screenspace_shaders.ssao import ssao_shader

# default_input = {
#     'numsamples' : 16,
#     'radius' : 0.01, # 0.05 is broken and cool
#     'amount' : 3.0,
#     'strength' : 0.001,
#     'falloff' : 0.000002,
#     'random_texture' : Func(load_texture, 'noise'),
# }
# )

